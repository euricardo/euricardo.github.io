jQuery(document).ready(function($) {

  "use strict";

  var options = {
    videoId : 'DG2iiJo5p1E',
    start : 10,
    mute: true
  };
  $('body').tubular(options);
});